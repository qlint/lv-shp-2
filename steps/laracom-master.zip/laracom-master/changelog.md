# Sept-17-2017

## Features

- Invoice on the order can be generated / downloaded as PDF
- Create email notifications
- Products search
- Order search
- Customer search
- Customer address search
- Transform the order with readable values
- Add the newsletter feature

## Bugs

- Redirect to `/admin` when already logged in
- Provinces / Cities API fix
- Reset password link fix
- Dynamic selection of cities in frontend