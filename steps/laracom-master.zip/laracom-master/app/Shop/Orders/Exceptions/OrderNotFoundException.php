<?php

namespace App\Shop\Orders\Exceptions;

class OrderNotFoundException extends \Exception
{
}
