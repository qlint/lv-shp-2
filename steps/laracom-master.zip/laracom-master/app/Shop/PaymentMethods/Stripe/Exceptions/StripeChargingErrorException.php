<?php

namespace App\Shop\PaymentMethods\Stripe\Exceptions;

class StripeChargingErrorException extends \Exception
{
}
