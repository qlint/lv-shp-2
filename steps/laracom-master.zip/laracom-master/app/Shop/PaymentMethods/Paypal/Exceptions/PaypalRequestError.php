<?php

namespace App\Shop\PaymentMethods\Paypal\Exceptions;

use Doctrine\Instantiator\Exception\InvalidArgumentException;

class PaypalRequestError extends InvalidArgumentException
{
}
