<?php

namespace App\Shop\OrderStatuses\Exceptions;

class OrderStatusNotFoundException extends \Exception
{
}
