<?php

namespace App\Shop\Products\Exceptions;

class ProductNotFoundException extends \Exception
{
}
