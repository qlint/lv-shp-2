<?php

namespace App\Shop\Products\Exceptions;

class ProductUpdateErrorException extends \Exception
{
}
