<?php

namespace App\Shop\Attributes\Exceptions;

class CreateAttributeErrorException extends \Exception
{
}
