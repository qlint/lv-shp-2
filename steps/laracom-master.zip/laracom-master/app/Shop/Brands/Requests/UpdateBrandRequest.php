<?php

namespace App\Shop\Brands\Requests;

use App\Shop\Base\BaseFormRequest;

class UpdateBrandRequest extends BaseFormRequest
{
    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [];
    }
}
