<?php

namespace App\Shop\Brands\Exceptions;

class DeletingBrandErrorException extends \Exception
{
}
