<?php

namespace App\Shop\Roles\Exceptions;

class DeleteRoleErrorException extends \Exception
{
}
