<?php

namespace App\Shop\Roles\Exceptions;

class RoleNotFoundErrorException extends \Exception
{
}
